# Execution summary

The C program compiled with GCC and executed successfully for all four input sizes. The table below summarizes operation counts from this run. Timing values are machine-dependent.

| n | Linear present comparisons | Linear absent comparisons | Binary present comparisons | Binary absent comparisons | Hash present probes | Hash absent probes |
|---:|---:|---:|---:|---:|---:|---:|
| 1,000 | 500 | 1000 | 1 | 18 | 1 | 1 |
| 10,000 | 5000 | 10000 | 1 | 26 | 1 | 1 |
| 100,000 | 50000 | 100000 | 1 | 32 | 1 | 1 |
| 1,000,000 | 500000 | 1000000 | 1 | 38 | 1 | 1 |

The chosen present key is the middle element after sorting, so binary search finds it in one comparison in this dataset. The hash function and selected table capacity result in one probe for these tested keys. Do not generalize these particular hash probe counts to all possible data distributions.
