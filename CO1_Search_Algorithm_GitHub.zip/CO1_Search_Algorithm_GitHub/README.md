# CO1 – Design and Analysis of Algorithms: Search Strategies

## Problem statement
Implement and compare three approaches for finding a student registration number in a dataset:
1. Iterative linear search
2. Recursive binary search (input must be sorted)
3. Hash-table lookup using open addressing and linear probing

The program tests 1,000, 10,000, 100,000, and 1,000,000 records and reports results, operation counts, preprocessing time, and search time.

## Files
- `search_assignment.c` — C source code for the three algorithms.
- `results.csv` — output captured from a completed run. Timing varies by computer; rerun locally for your final measurements.
- `execution_log.txt` — compile command, execution status, and program output.
- `RESULTS_SUMMARY.md` — summary of operation counts.

## Compile and run

### Linux / macOS
```bash
gcc -O2 -std=c11 -Wall -Wextra search_assignment.c -o search_assignment
./search_assignment > results.csv
```

### Windows with MinGW GCC
```bash
gcc -O2 -std=c11 -Wall -Wextra search_assignment.c -o search_assignment.exe
search_assignment.exe > results.csv
```

The program writes CSV data to standard output and a completion message to standard error.

## Complexity
| Algorithm | Preprocessing | Typical search | Worst-case search |
|---|---:|---:|---:|
| Linear search | None | O(n) | O(n) |
| Recursive binary search | O(n log n) sorting if needed | O(log n) | O(log n) |
| Hash table | Expected O(n) build | Expected O(1) | O(n) |

For `q` searches after preprocessing, the expected totals are `O(qn)` for linear search, `O(n log n + q log n)` for sorting once and using binary search, and `O(n + q)` for a well-distributed hash table.

## Tests
For every size, the program searches for one present registration number and one absent key (`-999`). It measures sorting and hash construction separately from lookup. The data contains unique integer registration numbers; a real system with string registration numbers would need a string hash function.

## Reporting note
Timings are hardware/compiler dependent. Use `results.csv` as the execution evidence for this run, and rerun the code on your own machine if your instructor expects your own environment's results. Operation counts are generally more stable than elapsed time.
