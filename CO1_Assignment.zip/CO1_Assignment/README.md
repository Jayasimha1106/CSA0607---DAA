# CO1 Assignment: Efficient Search Strategy for a Large-Scale Student Record System

**Course:** CSA06 Design and Analysis of Algorithms, SIMATS Engineering
**Student:** Jayasimha

## Project overview
Compares three strategies for locating a registration number among 1,000 to 1,000,000 student records, analyses them mathematically (basic operations, time complexity, best/average/worst case, asymptotics, recurrence) and validates the analysis experimentally. Includes the Day-4 design challenge (50,000 searches per hour on 1,000,000 records, new records once per day).

## Algorithms implemented
1. **Linear search**: iterative, brute force, no preprocessing.
2. **Binary search**: recursive, decrease and conquer, merge sort preprocessing.
3. **Hash table with chaining**: space-time trade-off, build preprocessing.

## How to run
Requirements: Python 3.9+ (matplotlib for graphs only).
```
cd Task_8_Implementation_Testing/Source_Code
python test_correctness.py     # correctness and edge-case tests
python run_benchmark.py        # writes Task_9_Experimental_Performance/results.csv (about 15 s)
python make_graphs.py          # graphs and tables into Report/Tables_and_Graphs/
```

## Repository structure
```
CO1_Assignment/
|-- Task_1_Algorithm_Design/            pseudocode, design strategy, preprocessing
|-- Task_2_Basic_Operation/
|-- Task_3_Mathematical_Complexity/
|-- Task_4_Case_Analysis/
|-- Task_5_Asymptotic_Analysis/
|-- Task_6_Recurrence_Formulation/
|-- Task_7_Recurrence_Solution/
|-- Task_8_Implementation_Testing/
|   |-- Source_Code/                    search_algorithms.py, test_correctness.py,
|                                       run_benchmark.py, make_graphs.py
|-- Task_9_Experimental_Performance/    results.csv, tables, graphs
|-- Task_10_Theory_vs_Experiment/
|-- Task_11_Final_Recommendation/
|-- Task_12_Design_Challenge/
|-- Report/
|   |-- Source_Code_Screenshots/
|   |-- Output_Screenshots/             test_output.txt, benchmark_output.txt
|   |-- Analysis/
|   |-- Tables_and_Graphs/              graph1-4 PNG, results_tables.md, day4_numbers.md
|   |-- Documentation/                  Full_Report.md
|-- README.md
```

## Results summary (n = 1,000,000, 200 mixed queries)
| Algorithm | Preprocessing | Time per search | Avg comparisons |
|---|---|---|---|
| Linear | none | 23.7 ms | 723,410 |
| Sort + binary | 2.38 s | 3.0 microseconds | 19.4 |
| Hash table | 0.86 s | 0.62 microseconds | 1.31 |

**Recommendation:** binary search on a sorted array in the general case (deterministic, ordered). For the Day-4 workload, **modify** the design to a hash table index rebuilt nightly, keeping the sorted array for range queries. Details in `Task_11_Final_Recommendation/` and `Task_12_Design_Challenge/`.

## Notes
- Timings come from one run on the author's machine; rerun on your own machine for your numbers.
- 200 queries per size were used (not more) so the 1,000,000-record linear search finishes quickly.
