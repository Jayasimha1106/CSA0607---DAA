#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define EMPTY (-1)
static long long comparisons;

static int cmp_int(const void *a, const void *b) {
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

int linear_search(const int a[], int n, int key) {
    comparisons = 0;
    for (int i = 0; i < n; i++) {
        comparisons++;
        if (a[i] == key) return i;
    }
    return -1;
}

int binary_search_recursive(const int a[], int low, int high, int key) {
    if (low > high) return -1;
    int mid = low + (high - low) / 2;
    comparisons++;
    if (a[mid] == key) return mid;
    comparisons++;
    if (key < a[mid]) return binary_search_recursive(a, low, mid - 1, key);
    return binary_search_recursive(a, mid + 1, high, key);
}

int hash_insert(int table[], int capacity, int key) {
    int index = ((key % capacity) + capacity) % capacity, probes = 0;
    while (table[index] != EMPTY && table[index] != key) {
        index = (index + 1) % capacity;
        if (++probes >= capacity) return 0;
    }
    table[index] = key;
    return 1;
}

int hash_search(const int table[], int capacity, int key, long long *probes) {
    int index = ((key % capacity) + capacity) % capacity;
    *probes = 0;
    while (table[index] != EMPTY) {
        (*probes)++;
        if (table[index] == key) return index;
        index = (index + 1) % capacity;
        if (*probes >= capacity) return -1;
    }
    (*probes)++;
    return -1;
}

static double seconds(clock_t start, clock_t end) {
    return (double)(end - start) / CLOCKS_PER_SEC;
}

int main(void) {
    const int sizes[] = {1000, 10000, 100000, 1000000};
    int count = (int)(sizeof(sizes) / sizeof(sizes[0]));
    puts("n,method,target,result,operations,time_seconds");

    for (int s = 0; s < count; s++) {
        int n = sizes[s];
        int *data = malloc((size_t)n * sizeof(int));
        if (!data) { fprintf(stderr, "Array allocation failed for n=%d\n", n); return EXIT_FAILURE; }
        for (int i = 0; i < n; i++) data[i] = 10000000 + (n - i);

        int present_key = 10000000 + n / 2;
        int absent_key = -999;
        clock_t start = clock();
        qsort(data, (size_t)n, sizeof(int), cmp_int);
        clock_t end = clock();
        printf("%d,sort,NA,complete,NA,%.6f\n", n, seconds(start, end));

        start = clock();
        int result = linear_search(data, n, present_key);
        end = clock();
        printf("%d,linear,present,%s,%lld,%.6f\n", n, result >= 0 ? "found" : "not_found", comparisons, seconds(start, end));
        start = clock();
        result = linear_search(data, n, absent_key);
        end = clock();
        printf("%d,linear,absent,%s,%lld,%.6f\n", n, result >= 0 ? "found" : "not_found", comparisons, seconds(start, end));

        comparisons = 0;
        start = clock();
        result = binary_search_recursive(data, 0, n - 1, present_key);
        end = clock();
        printf("%d,binary,present,%s,%lld,%.6f\n", n, result >= 0 ? "found" : "not_found", comparisons, seconds(start, end));
        comparisons = 0;
        start = clock();
        result = binary_search_recursive(data, 0, n - 1, absent_key);
        end = clock();
        printf("%d,binary,absent,%s,%lld,%.6f\n", n, result >= 0 ? "found" : "not_found", comparisons, seconds(start, end));

        int capacity = 2 * n + 1;
        int *table = malloc((size_t)capacity * sizeof(int));
        if (!table) { fprintf(stderr, "Hash allocation failed for n=%d\n", n); free(data); return EXIT_FAILURE; }
        for (int i = 0; i < capacity; i++) table[i] = EMPTY;
        start = clock();
        int ok = 1;
        for (int i = 0; i < n; i++) if (!hash_insert(table, capacity, data[i])) { ok = 0; break; }
        end = clock();
        printf("%d,hash_build,NA,%s,NA,%.6f\n", n, ok ? "complete" : "failed", seconds(start, end));
        if (!ok) { fprintf(stderr, "Hash insertion failed for n=%d\n", n); free(table); free(data); return EXIT_FAILURE; }

        long long probes = 0;
        start = clock(); result = hash_search(table, capacity, present_key, &probes); end = clock();
        printf("%d,hash,present,%s,%lld,%.6f\n", n, result >= 0 ? "found" : "not_found", probes, seconds(start, end));
        start = clock(); result = hash_search(table, capacity, absent_key, &probes); end = clock();
        printf("%d,hash,absent,%s,%lld,%.6f\n", n, result >= 0 ? "found" : "not_found", probes, seconds(start, end));

        if (linear_search(data, n, present_key) < 0) {
            fprintf(stderr, "Validation failed for n=%d\n", n); free(table); free(data); return EXIT_FAILURE;
        }
        free(table); free(data);
    }
    fprintf(stderr, "All dataset sizes completed.\n");
    return EXIT_SUCCESS;
}
